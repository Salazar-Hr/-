require 'net/http'
require 'uri'

def fetch_info(url)
  uri = URI.parse(url)
  response = Net::HTTP.get_response(uri)

  if response.is_a?(Net::HTTPSuccess)
    puts "[+] Response from #{url}:"
    puts response.body[0..500] 
  else
    puts "[-] Error fetching #{url}: #{response.code} #{response.message}"
  end
end


urls = [
  "http://localhost:3000",
  "http://example.com",     
  "https://example.com",    
  "http://your-cloudflare-url.com" 
]

urls.each do |url|
  fetch_info(url)
end
