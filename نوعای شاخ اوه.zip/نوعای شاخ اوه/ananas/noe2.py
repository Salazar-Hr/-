import os
import sys

def run_xsstrike(target_url):
    
    os.system(f'python3 xsstrike.py -u {target_url} --crawl')

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 xsstrike_script.py <target_url>")
        sys.exit(1)

    target_url = sys.argv[1]
    print(f"Starting XSStrike on target: {target_url}")
    run_xsstrike(target_url)
