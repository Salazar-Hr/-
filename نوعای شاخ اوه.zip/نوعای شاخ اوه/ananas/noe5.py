import paramiko
import sys

def ssh_connect(host, port, username, password):
    """اتصال به سرور SSH و اجرای دستورات"""
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host, port=port, username=username, password=password)

        print(f"اتصال به {host} برقرار شد.")

        stdin, stdout, stderr = client.exec_command('uname -a')
        print("اطلاعات سیستم:")
        print(stdout.read().decode())

        stdin, stdout, stderr = client.exec_command('who')
        print("کاربران فعال:")
        print(stdout.read().decode())

        client.close()
    except Exception as e:
        print(f"خطا در اتصال: {e}")

def main():
    host = input("لطفاً آدرس IP یا نام دامنه سرور را وارد کنید: ")
    port = int(input("لطفاً پورت SSH را وارد کنید (به طور پیش‌فرض 22): ") or 22)
    username = input("لطفاً نام کاربری را وارد کنید: ")
    password = input("لطفاً پسورد را وارد کنید: ")

    ssh_connect(host, port, username, password)

if __name__ == "__main__":
    main()
