from skyfield.api import load, Topos
from datetime import datetime

satellites = load.tle_file('http://celestrak.com/NORAD/elements/stations.txt')

user_location = Topos('34.3144 N', '47.0662 E')

ts = load.timescale()
t = ts.now()

for satellite in satellites:
    geocentric = satellite.at(t).position.au
    distance = ((geocentric[0]**2 + geocentric[1]**2 + geocentric[2]**2)**0.5) * 149597870.7  # تبدیل به کیلومتر

    if distance < 20000:
        print(f"Satellite: {satellite.name}")
        print(f"Distance: {distance:.2f} km")
        print(f"Current Time: {t.utc_strftime('%Y-%m-%d %H:%M:%S')}")
        print("----------------------------------------------------")
